import 'package:flutter/material.dart';
import 'app_colors.dart';
import 'board_point.dart';
import 'game_state.dart';

/// The real, interactive 12 Goti board, driven by [GameState].
///
/// AI currently just passes its turn with no intelligence yet — that comes
/// with the minimax engine later. This screen focuses on player moves,
/// capture chains (with manual stop/continue), and turn/win handling.
class GameBoardScreen extends StatefulWidget {
  const GameBoardScreen({super.key});

  @override
  State<GameBoardScreen> createState() => _GameBoardScreenState();
}

class _GameBoardScreenState extends State<GameBoardScreen> {
  late GameState _state;
  int? _selectedIndex;
  // when a capture chain is in progress, only continuing jumps (or tapping
  // the piece again to stop) are allowed — no plain moves mid-chain.
  bool _chainInProgress = false;

  @override
  void initState() {
    super.initState();
    _state = GameState.initial(firstTurn: Owner.player);
  }

  void _onPointTap(int index) {
    if (_state.phase != GamePhase.playing || _state.turn != Owner.player) return;

    // mid-chain: tapping the selected piece again stops the chain here
    if (_chainInProgress && _selectedIndex == index) {
      setState(() {
        _state.turn = _state.turn.opponent;
        _selectedIndex = null;
        _chainInProgress = false;
      });
      return;
    }

    if (_chainInProgress) {
      final continuations = _state.capturesFrom(_selectedIndex!);
      final match = continuations.where((m) => m.to == index);
      if (match.isEmpty) return; // must continue the chain or stop, nothing else
      _applyAndMaybeContinue(match.first);
      return;
    }

    final owner = _state.ownerAt(index);
    if (owner == Owner.player) {
      setState(() => _selectedIndex = _selectedIndex == index ? null : index);
      return;
    }

    if (_selectedIndex == null) return;

    final moves = _state.legalMovesFrom(_selectedIndex!);
    final chosen = moves.where((m) => m.to == index);
    if (chosen.isEmpty) return;

    // if multiple chain lengths land on the same tapped point, take the
    // longest one available directly to that point (rest are handled via
    // the manual continue/stop flow above for shorter partial chains)
    final move = chosen.reduce((a, b) => a.captured.length >= b.captured.length ? a : b);
    _applyAndMaybeContinue(move);
  }

  void _applyAndMaybeContinue(Move move) {
    setState(() {
      final wasCapture = move.captured.isNotEmpty;
      final landedAt = move.to;
      _state.applyMove(move); // this also flips turn + updates phase

      if (wasCapture && _state.phase == GamePhase.playing) {
        final more = _state.capturesFrom(landedAt);
        if (more.isNotEmpty) {
          // undo the automatic turn flip — chain continues under the same player
          _state.turn = _state.turn.opponent;
          _selectedIndex = landedAt;
          _chainInProgress = true;
          return;
        }
      }
      _selectedIndex = null;
      _chainInProgress = false;
    });
  }

  // TEMPORARY: no real AI yet — this just hands the turn back to the player
  // with no move made, purely so the full turn cycle can be tested.
  void _passAiTurn() {
    if (_state.turn != Owner.ai || _state.phase != GamePhase.playing) return;
    setState(() {
      _state.turn = Owner.player;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(
        backgroundColor: AppColors.background,
        elevation: 0,
        iconTheme: const IconThemeData(color: AppColors.textPrimary),
        title: const Text(
          'PLAY',
          style: TextStyle(
            color: AppColors.textPrimary,
            fontSize: 16,
            fontWeight: FontWeight.w600,
            letterSpacing: 2,
          ),
        ),
        centerTitle: true,
      ),
      body: SafeArea(
        child: Column(
          children: [
            const SizedBox(height: 8),
            _StatusBanner(state: _state, onTapAiTurn: _passAiTurn),
            Expanded(
              child: Center(
                child: Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 20),
                  child: AspectRatio(
                    aspectRatio: 1,
                    child: LayoutBuilder(
                      builder: (context, constraints) {
                        return Stack(
                          clipBehavior: Clip.none,
                          children: [
                            CustomPaint(
                              size: Size(constraints.maxWidth, constraints.maxHeight),
                              painter: _BoardLinesPainter(),
                            ),
                            for (final p in BoardGraph.points)
                              _PositionedPoint(
                                point: p,
                                size: constraints.maxWidth,
                                owner: _state.ownerAt(p.index),
                                isSelected: _selectedIndex == p.index,
                                onTap: () => _onPointTap(p.index),
                              ),
                          ],
                        );
                      },
                    ),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _StatusBanner extends StatelessWidget {
  const _StatusBanner({required this.state, required this.onTapAiTurn});

  final GameState state;
  final VoidCallback onTapAiTurn;

  @override
  Widget build(BuildContext context) {
    String label;
    Color color;

    switch (state.phase) {
      case GamePhase.playerWon:
        label = 'YOU WON';
        color = AppColors.playerStart;
        break;
      case GamePhase.aiWon:
        label = 'AI WON';
        color = AppColors.aiStart;
        break;
      case GamePhase.playing:
        final isPlayer = state.turn == Owner.player;
        label = isPlayer ? 'YOUR TURN' : "AI'S TURN (tap to pass — temp)";
        color = isPlayer ? AppColors.playerStart : AppColors.aiStart;
        break;
    }

    return GestureDetector(
      onTap: state.turn == Owner.ai && state.phase == GamePhase.playing ? onTapAiTurn : null,
      child: Padding(
        padding: const EdgeInsets.symmetric(vertical: 8),
        child: Text(
          label,
          style: TextStyle(color: color, fontSize: 13, letterSpacing: 1.5, fontWeight: FontWeight.w600),
        ),
      ),
    );
  }
}

class _PositionedPoint extends StatelessWidget {
  const _PositionedPoint({
    required this.point,
    required this.size,
    required this.owner,
    required this.isSelected,
    required this.onTap,
  });

  final BoardPoint point;
  final double size;
  final Owner? owner;
  final bool isSelected;
  final VoidCallback onTap;

  static const _margin = 0.06;

  Offset get _center {
    final left = size * _margin;
    final span = size * (1 - 2 * _margin);
    return Offset(
      left + span * (point.col / 4),
      left + span * (point.row / 4),
    );
  }

  @override
  Widget build(BuildContext context) {
    const hitSize = 44.0;
    final c = _center;
    return Positioned(
      left: c.dx - hitSize / 2,
      top: c.dy - hitSize / 2,
      width: hitSize,
      height: hitSize,
      child: GestureDetector(
        behavior: HitTestBehavior.opaque,
        onTap: onTap,
        child: owner == null
            ? const SizedBox.shrink()
            : _Piece(owner: owner!, isSelected: isSelected),
      ),
    );
  }
}

class _Piece extends StatefulWidget {
  const _Piece({required this.owner, required this.isSelected});

  final Owner owner;
  final bool isSelected;

  @override
  State<_Piece> createState() => _PieceState();
}

class _PieceState extends State<_Piece> with SingleTickerProviderStateMixin {
  late final AnimationController _pulseController;

  @override
  void initState() {
    super.initState();
    _pulseController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 900),
    )..repeat(reverse: true);
  }

  @override
  void dispose() {
    _pulseController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final baseColor = widget.owner == Owner.player ? AppColors.playerStart : AppColors.aiStart;

    if (!widget.isSelected) {
      return Center(
        child: Container(
          width: 18,
          height: 18,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            color: baseColor,
            boxShadow: [
              BoxShadow(color: baseColor.withValues(alpha: 0.35), blurRadius: 10, spreadRadius: 1),
            ],
          ),
        ),
      );
    }

    // Selected piece: slow pulsing size + glow, no static outline.
    return AnimatedBuilder(
      animation: _pulseController,
      builder: (context, _) {
        final t = _pulseController.value; // 0..1
        final scale = 1.0 + (t * 0.22); // gently grows/shrinks
        final glowAlpha = 0.4 + (t * 0.4);
        return Center(
          child: Transform.scale(
            scale: scale,
            child: Container(
              width: 24,
              height: 24,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: baseColor,
                boxShadow: [
                  BoxShadow(
                    color: baseColor.withValues(alpha: glowAlpha),
                    blurRadius: 18,
                    spreadRadius: 3,
                  ),
                ],
              ),
            ),
          ),
        );
      },
    );
  }
}

class _BoardLinesPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final linePaint = Paint()
      ..color = AppColors.boardLine
      ..strokeWidth = 1.5
      ..style = PaintingStyle.stroke;

    const margin = 0.06;
    final left = size.width * margin;
    final right = size.width * (1 - margin);
    final top = size.height * margin;
    final bottom = size.height * (1 - margin);
    final w = right - left;
    final h = bottom - top;

    Offset gridPoint(int col, int row) => Offset(left + w * (col / 4), top + h * (row / 4));

    for (var col = 0; col <= 4; col++) {
      canvas.drawLine(gridPoint(col, 0), gridPoint(col, 4), linePaint);
    }
    for (var row = 0; row <= 4; row++) {
      canvas.drawLine(gridPoint(0, row), gridPoint(4, row), linePaint);
    }

    for (var blockCol = 0; blockCol < 2; blockCol++) {
      for (var blockRow = 0; blockRow < 2; blockRow++) {
        final c0 = blockCol * 2;
        final r0 = blockRow * 2;
        canvas.drawLine(gridPoint(c0, r0), gridPoint(c0 + 2, r0 + 2), linePaint);
        canvas.drawLine(gridPoint(c0 + 2, r0), gridPoint(c0, r0 + 2), linePaint);
      }
    }

    canvas.drawCircle(gridPoint(2, 2), 3, Paint()..color = AppColors.boardCenterDot);
  }

  @override
  bool shouldRepaint(covariant _BoardLinesPainter oldDelegate) => false;
}
