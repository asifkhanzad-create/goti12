import 'board_point.dart';

enum Owner { player, ai }

extension OwnerX on Owner {
  Owner get opponent => this == Owner.player ? Owner.ai : Owner.player;
}

/// A single move: from one point to another, plus any pieces captured
/// along the way (empty if it was a plain, non-capturing move).
class Move {
  const Move({required this.from, required this.to, this.captured = const []});

  final int from; // point index
  final int to; // point index
  final List<int> captured; // point indices of jumped-over pieces
}

enum GamePhase { playing, playerWon, aiWon }

/// Holds board occupancy + whose turn it is, and exposes the rules:
/// legal moves, applying a move (with optional chain captures), and
/// win-condition checks. Pure logic — no Flutter/UI here.
class GameState {
  GameState({required Map<int, Owner?> occupants, required this.turn})
      : occupants = Map<int, Owner?>.from(occupants);

  final Map<int, Owner?> occupants; // point index -> owner or null
  Owner turn;
  GamePhase phase = GamePhase.playing;

  factory GameState.initial({required Owner firstTurn}) {
    final map = <int, Owner?>{};
    for (final p in BoardGraph.points) {
      if (p.isCenter) {
        map[p.index] = null;
      } else if (p.row <= 1) {
        map[p.index] = Owner.ai;
      } else if (p.row >= 3) {
        map[p.index] = Owner.player;
      } else {
        map[p.index] = p.col <= 1 ? Owner.player : Owner.ai;
      }
    }
    return GameState(occupants: map, turn: firstTurn);
  }

  Owner? ownerAt(int index) => occupants[index];

  /// Plain (non-capturing) moves available from [from]: adjacent + empty.
  List<int> plainMovesFrom(int from) {
    final owner = occupants[from];
    if (owner == null) return const [];
    return BoardGraph.neighborsOf(BoardPoint(from % 5, from ~/ 5))
        .where((n) => occupants[n] == null)
        .toList();
  }

  /// Single-jump captures available from [from]: an adjacent opponent piece
  /// with an empty landing point directly beyond it, in a straight line
  /// along an existing board connection.
  List<Move> capturesFrom(int from) {
    final owner = occupants[from];
    if (owner == null) return const [];
    final fromPoint = BoardPoint(from % 5, from ~/ 5);
    final moves = <Move>[];

    for (final midIndex in BoardGraph.neighborsOf(fromPoint)) {
      if (occupants[midIndex] != owner.opponent) continue;
      final midPoint = BoardPoint(midIndex % 5, midIndex ~/ 5);

      // landing point is the reflection of fromPoint through midPoint
      final landCol = midPoint.col * 2 - fromPoint.col;
      final landRow = midPoint.row * 2 - fromPoint.row;
      if (landCol < 0 || landCol > 4 || landRow < 0 || landRow > 4) continue;
      final landPoint = BoardPoint(landCol, landRow);

      // must be a real edge mid->land, and landing point must be empty
      if (!BoardGraph.areAdjacent(midPoint, landPoint)) continue;
      if (occupants[landPoint.index] != null) continue;

      moves.add(Move(from: from, to: landPoint.index, captured: [midIndex]));
    }
    return moves;
  }

  /// All capture chains starting at [from], fully expanded (each chain step
  /// is optional, so this returns every possible chain length including the
  /// single-jump ones).
  List<Move> captureChainsFrom(int from) {
    final results = <Move>[];

    void explore(int currentFrom, List<int> capturedSoFar, int originalFrom) {
      final owner = occupants[originalFrom];
      final tempOccupants = Map<int, Owner?>.from(occupants);
      tempOccupants[originalFrom] = null;
      for (final c in capturedSoFar) {
        tempOccupants[c] = null;
      }
      tempOccupants[currentFrom] = owner;

      final nextJumps = _capturesFromWithBoard(currentFrom, owner!, tempOccupants);
      if (nextJumps.isEmpty && capturedSoFar.isNotEmpty) {
        results.add(Move(from: originalFrom, to: currentFrom, captured: capturedSoFar));
        return;
      }
      if (capturedSoFar.isNotEmpty) {
        // chaining is optional — stopping here is also a valid move
        results.add(Move(from: originalFrom, to: currentFrom, captured: capturedSoFar));
      }
      for (final jump in nextJumps) {
        explore(jump.to, [...capturedSoFar, ...jump.captured], originalFrom);
      }
    }

    for (final jump in capturesFrom(from)) {
      explore(jump.to, jump.captured, from);
    }
    return results;
  }

  List<Move> _capturesFromWithBoard(int from, Owner owner, Map<int, Owner?> board) {
    final fromPoint = BoardPoint(from % 5, from ~/ 5);
    final moves = <Move>[];
    for (final midIndex in BoardGraph.neighborsOf(fromPoint)) {
      if (board[midIndex] != owner.opponent) continue;
      final midPoint = BoardPoint(midIndex % 5, midIndex ~/ 5);
      final landCol = midPoint.col * 2 - fromPoint.col;
      final landRow = midPoint.row * 2 - fromPoint.row;
      if (landCol < 0 || landCol > 4 || landRow < 0 || landRow > 4) continue;
      final landPoint = BoardPoint(landCol, landRow);
      if (!BoardGraph.areAdjacent(midPoint, landPoint)) continue;
      if (board[landPoint.index] != null) continue;
      moves.add(Move(from: from, to: landPoint.index, captured: [midIndex]));
    }
    return moves;
  }

  /// Every legal move for the piece at [from]: plain moves + all capture
  /// chain options. Captures are optional, so both lists are valid choices.
  List<Move> legalMovesFrom(int from) {
    final plain = plainMovesFrom(from).map((to) => Move(from: from, to: to)).toList();
    final captures = captureChainsFrom(from);
    return [...plain, ...captures];
  }

  /// All legal moves for [owner] across the whole board.
  List<Move> legalMovesFor(Owner owner) {
    final moves = <Move>[];
    for (final entry in occupants.entries) {
      if (entry.value == owner) {
        moves.addAll(legalMovesFrom(entry.key));
      }
    }
    return moves;
  }

  /// Applies [move]: relocates the piece, removes captured pieces, passes
  /// the turn, and updates win-condition phase. Does not itself decide
  /// whether to continue a chain — the caller picks which Move (how long a
  /// chain) to apply.
  void applyMove(Move move) {
    final owner = occupants[move.from];
    occupants[move.from] = null;
    for (final c in move.captured) {
      occupants[c] = null;
    }
    occupants[move.to] = owner;

    turn = turn.opponent;
    _updatePhase();
  }

  void _updatePhase() {
    final playerPieces = occupants.values.where((o) => o == Owner.player).length;
    final aiPieces = occupants.values.where((o) => o == Owner.ai).length;

    if (playerPieces == 0) {
      phase = GamePhase.aiWon;
      return;
    }
    if (aiPieces == 0) {
      phase = GamePhase.playerWon;
      return;
    }

    final turnHasMoves = legalMovesFor(turn).isNotEmpty;
    if (!turnHasMoves) {
      phase = turn == Owner.player ? GamePhase.aiWon : GamePhase.playerWon;
    }
  }
}
